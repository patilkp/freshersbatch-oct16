/*4.	Supply marks of three subject and declare the result, result declaration is based on  below conditions:
a.	Condition 1: -All subjects marks is greater than 60 is Passed 
b.	Condition 2: -Any two subjects marks are greater than 60 is Promoted
c.	Condition 3: -Any one subject mark is greater than 60 or all subjects’ marks less than 60 is failed.
*/

class Marksheet
{
 public static void main(String[] args) {
 int s1=100,s2=70,s3=12;
 
 
 if(s1 >60 && s2>60 && s3>60)
 {
	 System.out.println("Congratulations! U are pass");
 }



else if(s1>60 && s2>60 || s2>60 && s3>60 || s1>60 && s3>60)
{
	System.out.println("Congratulations! U are pass");
}

else if(s1<60 && s2<60 && s3<60)
 {
	 System.out.println("u are failed!");
 
 }
  else 
	 System.out.println("u are failed!");

}
}
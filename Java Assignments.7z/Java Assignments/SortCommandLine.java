/*3.	Pass integer numbers through command line & display them in sorted fashion. (Use Integer.parseInt() method)*/

public class SortCommandLine {

    public static void main(String[] args) {
		

  int i=Integer.parseInt(args[0]); 
  for(int j = 0; j <= args.length; j++) 
  {
	  System.out.println(i);
	  i++;
  }
 
 /*print sorted int array
    System.out.print("Sorted int array : ");
    for(int index=0; index < i1.length ; index++)
      System.out.print("  "  + i1[index]); */
	}

}     



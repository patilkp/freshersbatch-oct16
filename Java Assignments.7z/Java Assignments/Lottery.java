import java.util.*;
import java.util.Scanner;
class Lottery {
  public static void main(String[] args) {
    int c;
    Random t = new Random();
 
   
    for (c = 1; c <= 6; c++) {
      System.out.println(t.nextInt(49));
	  
	  /*code for reading numbers from user*/
	  
	  Scanner sc = new Scanner(System.in);
        int[] numbers = new int[4];
        for(int i = 0; i < 4; ++i) {
            numbers[i] = sc.nextInt();
    }
  }
}

}

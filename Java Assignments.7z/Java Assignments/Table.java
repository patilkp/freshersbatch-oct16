
/*5.	Write a program to display a table of given number. For example if supplied 5 then print */

class Table{
	public static void main(String args[]){
		int num = Integer.parseInt(args[0]);
		System.out.println("MULTIPLICATION TABLE");
		for(int i=1;i<=num;i++){
			for(int j=1;j<=10;j++){
				
				System.out.print(" "+i*j+" ");
			}
			System.out.print("\n");
		}
	}
}

import java.util.Scanner;
class CUIApp
{
  public static void main(String[] args) 
  {
  Scanner in = new Scanner(System.in);
   String s,s1,s2,s3;
   int count =0,i=0;
   
      System.out.println("Enter a Ur Login name:");
      s = in.nextLine();
	  
	  System.out.println("Enter a Ur Password:");
      s1 = in.nextLine();
	  
      System.out.println("Your login name is: "+s);
	  System.out.println("You password is: "+s1);
	  
	  for(i=0;i<=2;i++)
	  {
	   System.out.println("Enter a Ur Login name:");
       s2 = in.nextLine();
	  
	   System.out.println("Enter a Ur Password:");
       s3 = in.nextLine();
	   count ++;
	  }
	  
	   if (s==s2 && s1==s3)
	   {
		   System.out.println("Welcome"+s);
	   }
	   if(count ==3)
	   {
		   System.out.println("Contact to Admin please!");
	   }
  }
}
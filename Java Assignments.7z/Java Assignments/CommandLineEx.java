/* Program for command line arguments */
class CommandLineEx{ 
	public static void main(String args[])
	{  
	 System.out.println("Your argument is: "+args[0]);  
    }  
}